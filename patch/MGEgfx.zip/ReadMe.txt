Title: Classic Civ2 graphics for Test of Time
Type: Graphics
Categorty: Retro
Requirements: Test of Time (ToT)
Author Name: Cedric Greene
Author E-Mail: Cedric_Greene@yahoo.com
File Version: 1.0b
File Size: 396k
Synopisis: Original Civ 2 graphics for ToT
Description: Replacement files for Cities.bmp, Icons.bmp, Improvements.bmp, Terrain1.BMP, Terrain2.bmp, and units.bmp with original Civilizaion II graphics.
Installation:
 Extract these files into "Original" subfolder located within the Test of Time directory. You will need to delete any and all .spr files (animated units) and especially the static.spr file for these to work.