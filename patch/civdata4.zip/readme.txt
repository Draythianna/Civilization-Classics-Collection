This archive contains the mod for Civilization I for Windows that replaces original tileset with the DOS like one.

Installation: Backup civdata4.rsc in your CivWin directory and copy there the one from this archive.

Version 20080325:
	Fixed color of barbarians and colors of some other civilizations
	Changed color of the grid of city, so size of city is easier to read.