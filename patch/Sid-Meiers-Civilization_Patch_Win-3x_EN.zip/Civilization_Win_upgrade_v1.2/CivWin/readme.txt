Civ Patch (Win) v1.2

The official upgrade for Civilization for Windows from Microprose. 
This is only a performance enhancement and has no new features.
